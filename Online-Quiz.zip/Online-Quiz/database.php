<?php
//code establishes a connection to a MySQL database
$con= new mysqli('localhost','root','','exam')or die("Could not connect to mysql".mysqli_error($con));
?>